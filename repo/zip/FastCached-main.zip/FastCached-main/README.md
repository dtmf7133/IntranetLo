 FastCache    

 FastCache class ported to Memcached (same interface)  

 @package  OpenGallery   http://github.com/dtmf7133     
 @author   Daniele Bonini <code@numd.eu>    
 @version  2.0    
 @phpver   7.4 up     
 @access   public    
 @note You have to declare in your "config.inc" file - or whatever file you    
 use for the purpose, the following global constants:    
 define('CACHE_HOST', "localhost");    
 define('CACHE_PORT', "11211");    
 define('CACHE_APP_PREFIX', "MyAPP_12345");

For any need of software additions, plugins and improvements please write to <a href="mailto:info@numode.eu">info@numode.eu</a>  

To help please donate by clicking <a href="https://numd.eu/l/dona1">https://numd.eu/l/dona1</a> and filling the form.  

Feedback: <a href="mailto:code@numd.eu">code@numd.eu</a>
