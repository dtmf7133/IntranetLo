#!/bin/sh

sourcedir='/mnt/upload/'
destdir='/home/pathto/livework/'
for i in `cd $sourcedir; find $sourcedir -maxdepth 1 -name '*.tar'`; do
  if [ ! -d $sourdir$i ]; then
     j=`basename "$i"`
     ret=`tar -x -C "$destdir" -f "$sourcedir${j}"  2> _tartmp.log; cat _tartmp.log; rm _tartmp.log`
     if [ "X$ret" = "X" ]; then
       echo "$j was processed."
       echo "$j was processed." >> restorelivebackup.log
     else
       echo "$j has generated a tar error: $ret"
       echo "$j has generated a tar error: $ret" >> restorelivebackup.log
     fi
  else
    echo "$i is file!" 
    echo "$i is file!" >> restorelivebackup.log
    continue
  fi
done