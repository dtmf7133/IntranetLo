#!/bin/bash

workpath="/home/pathto/livework/"
destdir="/mnt/upload/"

echo "Starting backup $workpath to $destdir (y/n) ?"
read continue
if [ "X$continue" = "Xn" ]; then
  echo "done."
  exit 0
fi

if [ ! -d $destdir ]; then
  echo "dest folder doesn't exist!" 
  echo "dest folder doesn't exist" >> live2tar.log
  echo "abort."
  echo "abort." >> live2tar.log
  exit 1
fi 

let ii=0
for i in `cd $destdir; find $destdir -maxdepth 1 -name '*'`; do
  let ii=$ii+1
done

if [ "X$ii" != "X1" ]; then
  echo "dest folder is not empty (ii=$ii)"
  echo "dest folder is not empty (ii=$ii)" >> live2tar.log
  echo "abort."
  echo "abort." >> live2tar.log
  exit 1
fi

cd $workpath

jj=`basename "$workpath"`

#processing * (dir) in Work/..
sourcedir=$workpath

echo "" >> live2tar.log
echo `date` >> live2tar.log
echo "start processing:" >> live2tar.log
echo "find $sourcedir -maxdepth 1 -name '*'" >> live2tar.log

for i in `cd $sourcedir; find $sourcedir -maxdepth 1 -name '*'`; do
  echo "working on $i"
  echo "working on $i" >> live2tar.log
  j=`basename "$i"`
  echo "shortly: $j"
  echo "shortly: $j" >> live2tar.log

  if [ "X$j" = "X$jj" ]; then
    echo "$i is '.'!"
    echo "$i is '.'!" >> live2tar.log
    continue
  fi
  if [ "X$i" = "X." ]; then
    echo "$i is '.'!"
    echo "$i is '.'!" >> live2tar.log
    continue
  fi
  if [ "X$i" = "X.." ]; then
    echo "$i is '..'!"
    echo "$i is '..'!" >> live2tar.log
    continue
  fi
  if [ ! -d $sourdir$i ]; then
    echo "$i is file!" 
    echo "$i is file!" >> live2tar.log
    continue
  fi 
  ret=`tar -cf "$destdir${j}.tar" "${j}" 2> _tartmp.log; cat _tartmp.log; rm _tartmp.log`
  if [ "X$ret" = "X" ]; then
    echo "$j was processed."
    echo "$j was processed." >> live2tar.log
  else
    echo "$j has generated a tar error: $ret"
    echo "$j has generated a tar error: $ret" >> live2tar.log
  fi
done

echo "done."
