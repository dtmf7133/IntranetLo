# live2tar
Everyone its live work to tar files..

These scripts are supplied AS-IS, we don't take any responsibility for their missusage.

For any need of software additions, plugins and improvements please write to info@numode.eu

To help please donate by clicking https://numd.eu/l/dona1 and filling the form.

Feedback: code@numd.eu
