# syscleandoc
A sysclean wrapper with doc - MIT

Simply call it in this way:  
./syscleandoc  
<br>
Sysclean output is the same from a while, however I tested this script against sysclean ver 3.9 (7.7 stable)  
<br>
Hope you can find it somewhat useful. Have fun!  
<br>
For any need of software additions, plugins and improvements please write to <a href="mailto:info@numode.eu">info@numode.eu</a>    
<br>
To help please donate by clicking <a href="https://gaox.io/l/dona1">https://gaox.io/l/dona1</a> and filling the form.   
<br>
Screenshot:  

<img src="screenshot1.png">

Feedback: <a href="mailto:code@gaox.io">code@gaox.io</a>
